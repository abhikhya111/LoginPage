
const images = [{
    id: 1,
    src: "./images/img1.jpeg",
    alt: "Image 1"
},
{
    id: 2,
    src: "./images/img2.jpeg",
    alt: "Image 2 "
},
{
    id: 3,
    src: "./images/img3.jpeg",
    alt: "Image 3"
}
];
export default images;