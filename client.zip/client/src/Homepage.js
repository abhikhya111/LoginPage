import React from 'react'
import CarouselComponent from "./components/carousel.component";
import Multicarousel from './components/multicarousel';
import Navbar from "./components/Navbar"

export default function Homepage() {
  return (
    <div> <Navbar/>
    <CarouselComponent/>
    <Multicarousel/></div>
  )
}
