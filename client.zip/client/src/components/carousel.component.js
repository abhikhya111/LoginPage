import React, { useState ,useEffect} from "react";
import { Carousel } from 'react-responsive-carousel';
import "react-responsive-carousel/lib/styles/carousel.min.css";
import './carousel.css';
import { Modal, Button, Form } from 'react-bootstrap';
import axios from 'axios';
import { Navigate } from 'react-router-dom';
import WelcomePage from "./WelcomePage";

export default function CarouselComponent() {
    //Login user
    const [comments,setComments]=useState([])
    useEffect(() => {
        handleSubmitLogin();
      }, [])
      useEffect(() => {
        console.log(comments)
      }, [comments])
    const [showLogin, setShowLogin] = useState(false);
    const handleCloseLogin = () => setShowLogin(false);
    const handleShowLogin = () => setShowLogin(true);

    //For Login form
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [token, setToken] = useState();
    //Register User
    const [showRegister, setShowRegister] = useState(false);
    const handleCloseRegister = () => setShowRegister(false);
    const handleShowRegister = () => setShowLogin(true);

    //Form submit methods for register
    const handleSubmitRegister = async e => {
        e.preventDefault();
      
      }
    //Form submit methods for login
    const handleSubmitLogin = async e => {
        e.preventDefault();
        axios.post('http://localhost:4000/api/login', {
            email: email,
            password: password
          })
          .then(function (response) {
            console.log(response);
            setComments(response.data)    
            window.location.href = "http://localhost:3000/welcome";

            // setToken={setToken};
            // console.log(token);
           
          })
      
      }

      if(comments) {
          console.log('hi');
          <Navigate to="/welcome"/>
        // return <WelcomePage />
      }
    
    return (
        <>            
            
                    {/*Register model with form starts */}
            <Modal show={showRegister} onHide={handleCloseLogin}>
                <Modal.Header closeButton>
                    <Modal.Title>Register</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleSubmitRegister}>
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                            <Form.Label>Username</Form.Label>
                            <Form.Control type="text" placeholder="Enter Username" />
                          
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="formBasicEmail">
                            <Form.Label>Email address</Form.Label>
                            <Form.Control type="email" placeholder="Enter email" />
                          
                        </Form.Group>

                        <Form.Group className="mb-3" controlId="formBasicEmail">
                            <Form.Label>Age</Form.Label>
                            <Form.Control type="text" placeholder="Enter your Age" />
                          
                        </Form.Group>

                        <Form.Group className="mb-3" controlId="formBasicPassword">
                            <Form.Label>Password</Form.Label>
                            <Form.Control type="password" placeholder="Enter Password" />
                        </Form.Group>

                        <Form.Group className="mb-3" controlId="formBasicEmail">
                            <Form.Label>User Role</Form.Label>
                            <Form.Control type="text" placeholder="Enter User Role" />
                          
                        </Form.Group>
                    
                        <Button variant="primary" type="submit">
                            Submit
                        </Button>
                    </Form>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleCloseRegister}>
                        Close
                    </Button>
                   
                </Modal.Footer>
            </Modal>
            {/*Register model with form ends */}
            {/*Login model with form begins */}
            <Modal show={showLogin} onHide={handleCloseLogin}>
                <Modal.Header closeButton>
                    <Modal.Title>Login</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleSubmitLogin}>
                            
                        <Form.Group className="mb-3" controlId="formBasicEmail">
                            <Form.Label>Email address</Form.Label>
                            <Form.Control type="email" placeholder="Enter email" value={email} onChange={(e) => setEmail(e.target.value)} />
                          
                        </Form.Group>


                        <Form.Group className="mb-3" controlId="formBasicPassword">
                            <Form.Label>Password</Form.Label>
                            <Form.Control type="password" placeholder="Enter Password" value={password} onChange={(e) => setPassword(e.target.value)} />
                        </Form.Group>

              
                    
                        <Button variant="primary" type="submit">
                            Submit
                        </Button>
                    </Form>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleCloseLogin}>
                        Close
                    </Button>
                   
                </Modal.Footer>
            </Modal>
            {/*Login model with form ends */}



            <button className="buttonLogin" onClick={handleShowLogin} >Login</button>
            <button className="buttonRegister" onClick={handleShowRegister}>Register</button>
            <div className="carousel-wrapper">
                <Carousel infiniteLoop useKeyboardArrows autoPlay showArrows dynamicHeight showIndicators >
                    <div>
                        <img src="../images/img1.jpeg" />
                    </div>
                    <div>
                        <img src="../images/img4.jpeg" />
                    </div>
                    <div>
                        <img src="../images/img3.jpeg" />
                    </div>
                </Carousel>
            </div>
            {/* <div className="intro">
        <h4 className="we-do">WHAT WE DO?</h4>
        <h5 className="we-do-content">We Embrace Diversity and Deliver Customer Success. We use ServiceNow to unite IT
         operations, security management, risk management, and to deliver resilient services which are based on 
         customer-centered priorities.We help the customers realize the true potential of their product and provide
        them effective engineering solutions at each stage of the product development life cycle.We help organizations 
        in integrating new emerging technologies like RPA and DevOps into their ecosystem with an optimized cost.</h5>
        
        </div> */}
        </>
    );
}