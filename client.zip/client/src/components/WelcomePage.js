import React from 'react';
import Navbar from './Navbar';
import CarouselComponent from './carousel.component';
import Multicarousel from './multicarousel';

export default function WelcomePage() {
  return (
    <div>
        
        welcomePage</div>
  )
}
