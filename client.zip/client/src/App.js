import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Login from './Login';
import React, { useState } from 'react';

import {Routes, Route} from 'react-router-dom';
import WelcomePage from './components/WelcomePage';
import Homepage from './Homepage';

// function setToken(userToken) {
//   sessionStorage.setItem('token', JSON.stringify(userToken));

// }

// function getToken() {
//   const tokenString = sessionStorage.getItem('token');
//   const userToken = JSON.parse(tokenString);
//   return userToken?.token
// }

function App() {
  // const token = getToken();

  // if(!token) {
  //   return <Login setToken={setToken} />
  // }
  return (<>

   
    <Login/>

      {/* <Routes>
        <Route path="/welcome" element={<WelcomePage/>}></Route> 
        <Route path="/homepage" element={<Homepage/>}></Route>
      </Routes> */}

     
    </>
  );
}

export default App;
